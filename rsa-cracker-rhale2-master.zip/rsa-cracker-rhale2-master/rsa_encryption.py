def rsa_encrypt(plaintext, e, n):
    """RSA-encrypts the given plaintext."""
    Ciphertext = pow(plaintext, e, n)
    return Ciphertext


def rsa_decrypt(ciphertext, d, n):
    """RSA-decrypts the given ciphertext."""
    Plaintext = pow(ciphertext, d, n)
    return Plaintext
