from sympy.core.numbers import Integer
from factor_int_with_sympy import factor_int_with_sympy
from inverse_mod import inverse_mod
import sys


def crack_rsa(e, n):
    """
    Returns the private exponent for the given RSA public key.
    It cracks the encryption using a sophisticated factorization algorithm.
    """

    p, q = factor_int_with_sympy(n)
    phi = (p-1)*(q-1)
    d = inverse_mod(e,phi)
    return d


def crack_rsa_brute_force(e, n):
    d = 0
    for i in range(sys.maxsize):           
        for j in range(sys.maxsize):
            p = i
            q = j

            if p > 1 and q > 1 and (p % i) != 0 and (q % j) != 0:
                if p * q == n:
                    phi = (p-1)*(q-1)
                    d = inverse_mod(e,phi)
                    return d

            
    """
    Returns the private exponent for the given RSA public key.
    It cracks the encryption using brute force.
    """
    return d
