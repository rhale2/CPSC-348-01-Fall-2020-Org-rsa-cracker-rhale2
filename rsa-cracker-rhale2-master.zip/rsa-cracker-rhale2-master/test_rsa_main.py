from test_rsa import RsaTestResult, test_rsa
from rsa_encryption import rsa_decrypt, rsa_encrypt
from rsa_cracker import crack_rsa
from factor_int_with_sympy import factor_int_with_sympy



def main():
        #lowestBits, highestBits 

         #plaintext, e, n, keysize
        testingList = [11, 7, 33, 6], [22, 3,55, 6], [33,17,77, 7], [44, 5292724727, 8093802337, 33], [55, 65537, 193525589347327, 48], [66, 65537, 2547701629085297, 52], [77, 65537, 26205577898256853, 55], [88, 65537, 588035197746923243, 60], [99, 65537, 962650700322326636233, 70], [1010, 65537, 23800004200970185016117, 75], [1111, 65537, 122584996302390602628737, 77]
        testingListSize = len(testingList)  


        for i in range(testingListSize):
                print(" ************************ Test Case " + str(i+1) + "-" + str(testingList[i][3]) + " bits ************************")
        
                print("Inputs : ")
                # key_size, n, e, plaintext
                test = test_rsa(testingList[i][3], testingList[i][2], testingList[i][1], testingList[i][0])
                print("n: " + str(testingList[i][2]))
                print("e: " + str(testingList[i][1]))
                print("Plaintext: ")
                print("Expected: " + str(testingList[0][0]))
                print("Actual: " + str(test.plaintext))
                print("Ciphertext: ")
                print("Expected: " + str(test.ciphertext))    
                print("Actual: " + str(test.ciphertext))
                print("d: ")
                if i < 4:  
                        print("Expected: " + str(test.d))
                else:
                        print("Expected: Unknown")   
                print("Actual: " + str(test.d))
                print("Cracking Time: " + str(test.fast_time))
                if test.brute_force_time == -1:
                        print("Could not crack the key using brute force.")
                else:        
                        print("Brute-force Cracking Time: " + str(test.brute_force_time))

        """
    Displays the results of the test cases using the following format.
    If the expected d value is unknown, displays "Expected: Unknown".
    If the key is too large for the brute-force algorithm, instead of displaying the time, displays "Could not crack the key using brute force.".

    ************************ Test Case 1 - 6 bits ************************

    Inputs:
            n: 33
            e: 7

    plaintext:
            Expected: 11
            Actual:   11
    ciphertext:
            Expected: 11
            Actual:   11
    d:
            Expected: 3
            Actual:   3

    Cracking time:                  0.0 seconds.
    Brute-force cracking time:      0.0 seconds.



    ************************ Test Case 2 - 6 bits ************************
                                    ...

                                    ...


    ************************ Test Case 10 - 89 bits ************************

    Inputs:
            n: 337280666197853981964619871
            e: 65537

    plaintext:
            Expected: 1010
            Actual:   1010
    ciphertext:
            Expected: 81243128398559957992827824
            Actual:   81243128398559957992827824
    d:
            Expected: Unknown
            Actual:   <your_answer_here>

    Cracking time:                  0.98 seconds.
    Could not crack the key using brute force.
    """
        return

if __name__ == "__main__":
    main()
    
